<?php
$sys_title_ = "Robopages";
$sys_layout = "robo";
$sys_defaultto = "me@myaddress.net";
$sys_interval = "3000";
$sys_defpage = "index";
$sys_defk = "keyword1,keyword2,keyword3";
$sys_defd = "Robopages -- A CMS with layouts defined in XML";
$sys_show_suffixes = TRUE;
$sys_thumb_links = TRUE;
$sys_main_content_div_id = 'main-content';
?>
