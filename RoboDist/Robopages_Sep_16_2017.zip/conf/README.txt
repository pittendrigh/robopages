dirLStart.conf.ini is needed only if you want to put robopages inside the public_html directory of a unix home user account.
If so, you also need to edit the main index.php so it includes dirCrawler.class.php instead of robopages.php
