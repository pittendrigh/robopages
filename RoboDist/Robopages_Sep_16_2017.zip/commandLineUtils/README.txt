I administer robopages sites with scp and ssh
For most administration chores I ssh into the server and run various bash and perl command line tools.
There are no admin.php like scripts for hackers to exploit.

Anyone who feels the need for a point-and-click administration GUI could install phpMyAdmin.
I feel safer without.  

Not too: mkslides depends on imagemagick and perl's Image::Size

